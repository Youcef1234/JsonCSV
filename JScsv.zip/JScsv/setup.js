//Firebase configuration


var firebaseConfig = {
    apiKey: "AIzaSyBz4c7bXkBDTL25bLvux2NkKxxjGYyrgo4",
    authDomain: "jsonproject-2e3a4.firebaseapp.com",
    databaseURL: "https://jsonproject-2e3a4.firebaseio.com",
    projectId: "jsonproject-2e3a4",
    storageBucket: "jsonproject-2e3a4.appspot.com",
    messagingSenderId: "1083634661556",
    appId: "1:1083634661556:web:7a02976ea1c085d01c3fe1"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);

//URL Database

// https://jsonproject-2e3a4.firebaseio.com/